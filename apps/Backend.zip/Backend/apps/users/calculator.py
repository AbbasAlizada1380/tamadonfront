def add(num, num2):
    """add(num, num2)"""
    return num + num2


def subtract(num, num2):
    """subtract two numbers"""
    return num - num2
